# OS Assignment - 2

Message types

1. `1` -> Ready for takeoff. plane sends this message to ATC
2. `2` -> ATC informs dept airport to begin boarding/loading, and takeoff
3. `3` -> Dept airport informs ATC that takeoff is done
4. `4` -> ATC informs arriv airport reg arrival of plane
5. `5` -> Arriv airport informs ATC that plane has landed & deboarded
6. `6` -> ATC informs plane to exit
7. `7` -> Cleanup message recv
8. `8` -> ATC tells plane process to sleep for 30 s
9. `9` -> Plane process informs ATC that it's sleep period is over
10. `10` -> ATC informs airports to close
